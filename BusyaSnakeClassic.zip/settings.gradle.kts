rootProject.name = "BusyaSnakeClassic"
include(":app")